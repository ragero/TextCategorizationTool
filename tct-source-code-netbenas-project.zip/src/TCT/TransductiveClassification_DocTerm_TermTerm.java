//*****************************************************************************
// Author: Rafael Geraldeli Rossi
// E-mail: rgr.rossi at gmail com
// Last-Modified: January 29, 2015
// Description: Class to perform Transductive Learning and Evaluations.
//              The algoritms are based on networks composed by document-term
//              and term-term relations.
//*****************************************************************************

package TCT;

import TCTNetworkGeneration.TermNetworkGeneration;
import TCTParameters.Parameters_GNetMine_DocTerm_TermTerm;
import TCTParameters.SemiSupervisedLearning.Parameters_LPHN;
import TCTParameters.Parameters_TermNetwork;
import TCTParameters.SemiSupervisedLearning.Parameters_IMHN;
import TCTAlgorithms.Transductive.TransductiveClassifier;
import TCTAlgorithms.Transductive.GNetMine_DocTerm_TermTerm_Transductive_ID;
import TCTAlgorithms.Transductive.LPHN_DocTerm_TermTerm_Transductive_ID;
import TCTAlgorithms.Transductive.TCHN_DocTerm_TermTerm_Transductive_ID;
import TCTConfigurations.TransductiveLearning.TransductiveConfiguration_DocTermAndTermTermRelations;
import TCTStructures.Neighbor;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import weka.core.Attribute;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils;

/*Function to read the data (document-term matrix and term probabilities) and build relations among terms. */
public class TransductiveClassification_DocTerm_TermTerm {
        
    public static void learning(TransductiveConfiguration_DocTermAndTermTermRelations configuration){
        
        File fileArff = new File(configuration.getArff());
        File fileProb = new File(configuration.getArqProb());
        File dirSaida = new File(configuration.getDirSaida());
        
        int numTerms = 0;
        
        if(!fileArff.getAbsolutePath().endsWith(".arff")){
            System.out.println("Invalid ARF file");
            return;
        }
        if(!fileProb.getAbsolutePath().endsWith(".prb")){
            System.out.println("Invalid probability file");
            return;
        }
        if(!dirSaida.exists()){
            System.out.println("Output directory does not exist");
            return;
        }
        
        System.out.println(fileArff.getAbsolutePath());
        System.out.println("Loading ARFF file");
        Instances dataOriginal = null;
        int numClasses = 0;
        try{
            ConverterUtils.DataSource trainSource = new ConverterUtils.DataSource(fileArff.getAbsolutePath().toString()); //Carregando arquivo de Dados
            dataOriginal = trainSource.getDataSet();

            Attribute classAtt = null;
            numTerms = dataOriginal.numAttributes()-1;
            classAtt = dataOriginal.attribute(numTerms); //Setting the last feature as class
            dataOriginal.setClass(classAtt);
            numClasses = classAtt.numValues();

            for(int j=0;j<numClasses;j++){
                System.out.println(j + ": " + classAtt.value(j));
            }

        }catch(Exception e){
            System.err.println("Error when reading document-term matrix.");
            e.printStackTrace();
            System.exit(0);
        }
        
        StringBuilder outputFile = new StringBuilder();
        outputFile.append(configuration.getDirSaida());
        outputFile.append("/");
        outputFile.append(dataOriginal.relationName());
        outputFile.append("_Transductive_DTandTT_");
        
        try{
            
        
            //Gerando as networks de Termos
            if(configuration.isSupportNetwork()){
                StringBuilder outputFilePar = new StringBuilder();
                outputFilePar.append("Support");
                outputFilePar.append("_");
                Parameters_TermNetwork parametersSupportNetwork = configuration.getParametersSupportNetwork();
                if(parametersSupportNetwork.getThresholdNetwork()){
                    for(int lim=0;lim<parametersSupportNetwork.getThresholds().size();lim++){
                        final double threshold = parametersSupportNetwork.getThreshold(lim);
                        ExecutorService threads = Executors.newFixedThreadPool(configuration.getNumThreads());
                        Neighbor[] adjacencyListTerms = TermNetworkGeneration.GenerateSupportNetworkThreshold(fileProb,numTerms,threshold,parametersSupportNetwork.getRelative());
                        learning(configuration, threads, adjacencyListTerms,outputFile.toString(),outputFilePar.toString() + "_Threshold_" + threshold + "_",dataOriginal,numClasses);
                        threads.shutdown();
                        boolean exit = false;
                        while(exit == false){
                            if(threads.isTerminated()){
                                exit = true;
                            }else{
                                Thread.sleep(1000);
                            }
                        }
                    }    
                }
                if(parametersSupportNetwork.getNetworkTopK()){
                    for(int topK=0;topK<parametersSupportNetwork.getKs().size();topK++){
                        final int k = parametersSupportNetwork.getK(topK);
                        ExecutorService threads = Executors.newFixedThreadPool(configuration.getNumThreads());
                        Neighbor[] adjacencyListTerms = TermNetworkGeneration.GenerateSupportNetworkTopK(fileProb,numTerms,k);
                        learning(configuration, threads, adjacencyListTerms,outputFile.toString(),outputFilePar.toString() + "_TopK_" + k + "_",dataOriginal,numClasses);
                        threads.shutdown();
                        boolean exit = false;
                        while(exit == false){
                            if(threads.isTerminated()){
                                exit = true;
                            }else{
                                Thread.sleep(1000);
                            }
                        }
                    }
                }

            }
            if(configuration.isMutualInformationNetwork()){
                StringBuilder outputFilePar = new StringBuilder();
                outputFilePar.append("MutualInformation");
                outputFilePar.append("_");
                Parameters_TermNetwork parametersMutualInformationNetwork = configuration.getParametersMutualInformationNetwork();
                if(parametersMutualInformationNetwork.getThresholdNetwork()){
                    for(int lim=0;lim<parametersMutualInformationNetwork.getThresholds().size();lim++){
                        final double threshold = parametersMutualInformationNetwork.getThreshold(lim);
                        ExecutorService threads = Executors.newFixedThreadPool(configuration.getNumThreads());
                        Neighbor[] adjacencyListTerms = TermNetworkGeneration.GenerateMutualInformationNetworkThreshold(fileProb,numTerms,threshold,parametersMutualInformationNetwork.getRelative());
                        learning(configuration, threads, adjacencyListTerms,outputFile.toString(),outputFilePar.toString() + "_Threshold_" +threshold + "_",dataOriginal,numClasses);
                        threads.shutdown();
                        boolean exit = false;
                        while(exit == false){
                            if(threads.isTerminated()){
                                exit = true;
                            }else{
                                Thread.sleep(1000);
                            }
                        }
                    }    
                }
                if(parametersMutualInformationNetwork.getNetworkTopK()){
                    for(int topK=0;topK<parametersMutualInformationNetwork.getKs().size();topK++){
                        final int k = parametersMutualInformationNetwork.getK(topK);
                        ExecutorService threads = Executors.newFixedThreadPool(configuration.getNumThreads());
                        Neighbor[] adjacencyListTerms = TermNetworkGeneration.GenerateMutualInformationNetworkTopK(fileProb,numTerms,k);
                        learning(configuration, threads, adjacencyListTerms,outputFile.toString(),outputFilePar.toString() + "_TopK_" + k + "_",dataOriginal,numClasses);
                        threads.shutdown();
                        boolean exit = false;
                        while(exit == false){
                            if(threads.isTerminated()){
                                exit = true;
                            }else{
                                Thread.sleep(1000);
                            }
                        }
                    }
                }
            }
            if(configuration.isKappaNetwork()){
                StringBuilder outputFilePar = new StringBuilder();
                outputFilePar.append("Kappa");
                outputFilePar.append("_");
                Parameters_TermNetwork parametersKappaNetwork = configuration.getParametersKappaNetwork();
                if(parametersKappaNetwork.getThresholdNetwork()){
                    for(int lim=0;lim<parametersKappaNetwork.getThresholds().size();lim++){
                        final double threshold = parametersKappaNetwork.getThreshold(lim);
                        ExecutorService threads = Executors.newFixedThreadPool(configuration.getNumThreads());
                        Neighbor[] adjacencyListTerms = TermNetworkGeneration.GenerateKappaNetworkThreshold(fileProb,numTerms,threshold,parametersKappaNetwork.getRelative());
                        learning(configuration, threads, adjacencyListTerms,outputFile.toString(),outputFilePar.toString() + "_Threshold_" +threshold + "_",dataOriginal,numClasses);
                        threads.shutdown();
                        boolean exit = false;
                        while(exit == false){
                            if(threads.isTerminated()){
                                exit = true;
                            }else{
                                Thread.sleep(1000);
                            }
                        }
                    }    
                }
                if(parametersKappaNetwork.getNetworkTopK()){
                    for(int topK=0;topK<parametersKappaNetwork.getKs().size();topK++){
                        final int k = parametersKappaNetwork.getK(topK);
                        ExecutorService threads = Executors.newFixedThreadPool(configuration.getNumThreads());
                        Neighbor[] adjacencyListTerms = TermNetworkGeneration.GenerateKappaNetworkTopK(fileProb,numTerms,k);
                        learning(configuration, threads, adjacencyListTerms,outputFile.toString(),outputFilePar.toString() + "_TopK_" + k + "_",dataOriginal,numClasses);
                        threads.shutdown();
                        boolean exit = false;
                        while(exit == false){
                            if(threads.isTerminated()){
                                exit = true;
                            }else{
                                Thread.sleep(1000);
                            }
                        }
                    }
                }    
            }
            if(configuration.isShapiroNetwork()){
                StringBuilder outputFilePar = new StringBuilder();
                outputFilePar.append("Shapiro");
                outputFilePar.append("_");
                Parameters_TermNetwork parametersShapiroNetwork = configuration.getParametersShapiroNetwork();
                if(parametersShapiroNetwork.getThresholdNetwork()){
                    for(int lim=0;lim<parametersShapiroNetwork.getThresholds().size();lim++){
                        final double threshold = parametersShapiroNetwork.getThreshold(lim);
                        ExecutorService threads = Executors.newFixedThreadPool(configuration.getNumThreads());
                        Neighbor[] adjacencyListTerms = TermNetworkGeneration.GenerateShapiroNetworkThreshold(fileProb,numTerms,threshold,parametersShapiroNetwork.getRelative());
                        learning(configuration, threads, adjacencyListTerms,outputFile.toString(),outputFilePar.toString() + "_Threshold_" + threshold + "_",dataOriginal,numClasses);
                        threads.shutdown();
                        boolean exit = false;
                        while(exit == false){
                            if(threads.isTerminated()){
                                exit = true;
                            }else{
                                Thread.sleep(1000);
                            }
                        }
                    }    
                }
                if(parametersShapiroNetwork.getNetworkTopK()){
                    for(int topK=0;topK<parametersShapiroNetwork.getKs().size();topK++){
                        final int k = parametersShapiroNetwork.getK(topK);
                        ExecutorService threads = Executors.newFixedThreadPool(configuration.getNumThreads());
                        Neighbor[] adjacencyListTerms = TermNetworkGeneration.GenerateShapiroNetworkTopK(fileProb,numTerms,k);
                        learning(configuration,threads, adjacencyListTerms, outputFile.toString(), outputFilePar.toString() + "_TopK_" + k + "_",dataOriginal,numClasses);
                        threads.shutdown();
                        boolean exit = false;
                        while(exit == false){
                            if(threads.isTerminated()){
                                exit = true;
                            }else{
                                Thread.sleep(1000);
                            }
                        }
                    }
                }    
            }
            if(configuration.isYulesQNetwork()){
                StringBuilder outputFilePar = new StringBuilder();
                outputFilePar.append("Yule's Q");
                outputFilePar.append("_");
                Parameters_TermNetwork parametersYulesQNetwork = configuration.getParametersYulesQNetwork();
                if(parametersYulesQNetwork.getThresholdNetwork()){
                    for(int lim=0;lim<parametersYulesQNetwork.getThresholds().size();lim++){
                        final double threshold = parametersYulesQNetwork.getThreshold(lim);
                        ExecutorService threads = Executors.newFixedThreadPool(configuration.getNumThreads());
                        Neighbor[] adjacencyListTerms = TermNetworkGeneration.GenerateYulesQNetworkThreshold(fileProb,numTerms,threshold,parametersYulesQNetwork.getRelative());
                        learning(configuration, threads, adjacencyListTerms,outputFile.toString(),outputFilePar.toString() + "_Threshold_" + threshold + "_",dataOriginal,numClasses);
                        threads.shutdown();
                        boolean exit = false;
                        while(exit == false){
                            if(threads.isTerminated()){
                                exit = true;
                            }else{
                                Thread.sleep(1000);
                            }
                        }
                    }       
                }
                if(parametersYulesQNetwork.getNetworkTopK()){
                    for(int topK=0;topK<parametersYulesQNetwork.getKs().size();topK++){
                        final int k = parametersYulesQNetwork.getK(topK);
                        ExecutorService threads = Executors.newFixedThreadPool(configuration.getNumThreads());
                        Neighbor[] adjacencyListTerms = TermNetworkGeneration.GenerateYulesQNetworkTopK(fileProb,numTerms,k);
                        learning(configuration, threads, adjacencyListTerms,outputFile.toString(),outputFilePar.toString() + "_TopK_" + k + "_",dataOriginal,numClasses);
                        threads.shutdown();
                        boolean exit = false;
                        while(exit == false){
                            if(threads.isTerminated()){
                                exit = true;
                            }else{
                                Thread.sleep(1000);
                            }
                        }
                    }
                }
            }

            System.out.println("Process concluded successfully");
            configuration.getEmail().getContent().append(configuration.toString());
            configuration.getEmail().send();
            
        }catch(Exception e){
            System.err.println("Error when performing learning");
            e.printStackTrace();
        }
    }

    //Function to set the parameters of transductive learning algorithms
    public static void learning(TransductiveConfiguration_DocTermAndTermTermRelations configuration, ExecutorService threads, Neighbor[] adjacencyListTerms, String output, String output2, Instances dataOriginal,int numClasses){
        
        
        for(int numEx=0;numEx<configuration.getParametersNumLabeledInstancesPerClass().getNumLabeledInstancesPerClass().size();numEx++){
            double numLabeledInstances = configuration.getParametersNumLabeledInstancesPerClass().getNumLabeledInstancesPerClass(numEx);
            StringBuilder outputFilePar = new StringBuilder();
            outputFilePar.append(numLabeledInstances);
            outputFilePar.append("_");
            if(configuration.isPorcentage() == true){
                outputFilePar.append("percentage");
                outputFilePar.append("_");
            }else{
                outputFilePar.append("real");
                outputFilePar.append("_");
            }
            if(configuration.isIMHN()){
                StringBuilder outputFilePar2 = new StringBuilder();
                outputFilePar2.append(outputFilePar);
                outputFilePar2.append("TCHN_");
                Parameters_IMHN parametersIMHN = configuration.getParameters_IMHN();
                for(int error=0;error<parametersIMHN.getErrors().size();error++){
                    for(int apr=0;apr<parametersIMHN.getErrorCorrectionRates().size();apr++){
                        //System.out.println("Number of labeled intances per class: " + numLabeledInstances);
                        //System.out.println("Classification Algorithm: TCHN DDeTT");
                        //System.err.println("Error Mínimo: " + parametersIMHN.getError(error));
                        //System.out.println("Learning Rate: " + parametersIMHN.getErrorCorrectionRate(apr));
                        StringBuilder outputFilePar3 = new StringBuilder();
                        outputFilePar3.append(parametersIMHN.getErrorCorrectionRate(apr));
                        outputFilePar3.append("_");
                        outputFilePar3.append(parametersIMHN.getError(error));
                        outputFilePar3.append("_");
                        TransductiveClassifier[] classifiers = new TransductiveClassifier[configuration.getNumReps()];
                        for(int rep=0;rep<configuration.getNumReps();rep++){
                            TCHN_DocTerm_TermTerm_Transductive_ID classifIMHN = new TCHN_DocTerm_TermTerm_Transductive_ID();
                            classifIMHN.setAdjacencyListTerms(adjacencyListTerms);
                            classifIMHN.setUse(0);
                            classifIMHN.setErrorCorrectionRate(parametersIMHN.getErrorCorrectionRate(apr));
                            classifIMHN.setMinError(parametersIMHN.getError(error));
                            classifIMHN.setmaxNumberLocalIterations(parametersIMHN.getMaxNumberIterationsLocal());
                            classifIMHN.setmaxNumberGlobalIterations(parametersIMHN.getMaxNumberIterationsGlobal());
                            classifiers[rep] = classifIMHN;
                        }
                        learning(configuration, threads, classifiers, dataOriginal, output + outputFilePar2.toString() + output2 + outputFilePar3.toString(), numLabeledInstances, numClasses);    
                    }
                }    
            }
            if(configuration.isLPHN()){
                StringBuilder outputFilePar2 = new StringBuilder();
                outputFilePar2.append(outputFilePar);
                outputFilePar2.append("LPHN_");
                Parameters_LPHN parametersLPHN = configuration.getParameters_LPHN();
                //System.out.println("Number of labeled intances per class: " + numLabeledInstances);
                //System.out.println("Classification Algorithm: LPHNDDeTT");
                TransductiveClassifier[] classifiers = new TransductiveClassifier[configuration.getNumReps()];
                for(int rep=0;rep<configuration.getNumReps();rep++){
                    LPHN_DocTerm_TermTerm_Transductive_ID classifLPHN = new LPHN_DocTerm_TermTerm_Transductive_ID();
                    classifLPHN.setUse(0);
                    classifLPHN.setAdjacencyListTerms(adjacencyListTerms);
                    classifLPHN.setMaxNumIterations(parametersLPHN.getMaxNumberIterations());
                    classifiers[rep] = classifLPHN;
                }
                learning(configuration, threads, classifiers, dataOriginal, output + outputFilePar2.toString() + output2, numLabeledInstances, numClasses);    
            }
            if(configuration.isGNetMine()){
                StringBuilder outputFilePar2 = new StringBuilder();
                outputFilePar2.append(outputFilePar);
                outputFilePar2.append("GNetMine_");
                Parameters_GNetMine_DocTerm_TermTerm parametersGNetMine = configuration.getParameters_GNetMine();
                for(int alpha=0;alpha<parametersGNetMine.getAlphasDocs().size();alpha++){
                    for(int lambda=0;lambda<parametersGNetMine.getLambdasDocTermo().size();lambda++){
                        //System.out.println("Number of labeled intances per class: " + numLabeledInstances);
                        //System.out.println("Classification Algorithm: GNetMine");
                        //System.out.println("Alpha Doc: " + parametersGNetMine.getAlphaDoc(alpha));
                        //System.out.println("Lambda DocTermo: " + parametersGNetMine.getLambdaDocTermo(lambda));
                        StringBuilder outputFilePar3 = new StringBuilder();
                        outputFilePar3.append("_");
                        outputFilePar3.append(parametersGNetMine.getAlphaDoc(alpha));
                        outputFilePar3.append("_");
                        outputFilePar3.append(parametersGNetMine.getLambdaDocTermo(lambda));
                        TransductiveClassifier[] classifiers = new TransductiveClassifier[configuration.getNumReps()];
                        for(int rep=0;rep<configuration.getNumReps();rep++){
                            GNetMine_DocTerm_TermTerm_Transductive_ID classifGNetMine = new GNetMine_DocTerm_TermTerm_Transductive_ID();
                            classifGNetMine.setUse(0);
                            classifGNetMine.setMaxNumIterations(parametersGNetMine.getMaxNumberIterations());
                            classifGNetMine.setAlphaDoc(parametersGNetMine.getAlphaDoc(alpha));
                            classifGNetMine.setLambdaDocTermo(parametersGNetMine.getLambdaDocTermo(lambda));
                            classifGNetMine.setAdjacencyListTerms(adjacencyListTerms);
                            classifiers[rep] = classifGNetMine;
                        }
                        learning(configuration, threads, classifiers, dataOriginal, output + outputFilePar2.toString() + output2 + outputFilePar3.toString(), numLabeledInstances, numClasses);    
                    }
                    
                }    
            }
        }
    }
    
    //Function to run and evaluate transductive learning
    public static void learning(final TransductiveConfiguration_DocTermAndTermTermRelations configuration, final ExecutorService threads, final TransductiveClassifier[] classifiers, final Instances dataOriginal, final String outputFile, final double numInstPerClass, final int numClasses){
        try{
            
            final Results results;
            
            final File output = new File(outputFile);
            final File outputResult = new File(output.getAbsolutePath() + ".txt");
            if(outputResult.exists()){
                return;
            }
            final File outputTemp = new File(output.getAbsolutePath() + ".tmp");
            
            if(outputTemp.exists()){
                ObjectInputStream objInput = new ObjectInputStream(new FileInputStream(output.getAbsolutePath() + ".tmp"));
                results = (Results)objInput.readObject();
                objInput.close();
            }else{
                results = new Results(output, configuration.getNumReps(), 1, "Transductive");
            }
            
            //System.out.println("Output: " + output.getAbsolutePath());
            
            for(int rep=0;rep<configuration.getNumReps();rep++){
                
                if(results.getComplete(rep, 0) == true){
                    continue;
                }
                
                final int numRep = rep;
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run(){
                        Integer[][] confusionMatrix = new Integer[numClasses][numClasses]; 
                        for(int class1=0;class1<numClasses;class1++){
                            for(int class2=0;class2<numClasses;class2++){
                                confusionMatrix[class1][class2] = 0;
                            }
                        }

                        Instances dataTrain = new Instances(dataOriginal,0);
                        Instances dataTest = new Instances(dataOriginal,0);

                        Instances data = new Instances(dataOriginal);
                        data.randomize(new Random(numRep));

                        SplitData.splitTrainTestTransductive(configuration, data, dataTrain, dataTest, numInstPerClass);

                        classifiers[numRep].setNumIterations(0);
                        long begin = System.currentTimeMillis();
                        try{
                            classifiers[numRep].buildClassifier(dataTrain, dataTest);
                        }catch(OutOfMemoryError e){
                            e.printStackTrace();
                            System.exit(0);
                        }catch(Exception e){
                            e.printStackTrace();
                            System.exit(0);
                        }
                        
                        long end  = System.currentTimeMillis();
                        results.setBuildingTime(numRep, 0, end - begin);
                        results.setNumIterations(numRep, 0, classifiers[numRep].getNumiterations());
                        begin = System.currentTimeMillis();
                        Evaluations.TransductiveEvaluation(classifiers[numRep], dataTest, confusionMatrix);
                        end = System.currentTimeMillis();
                        results.setClassificationTime(numRep, 0, end - begin);

                        results.computeEvaluationMeasures(confusionMatrix, numClasses, numRep, 0);
                        results.setComplete(numRep, 0, true);
                        
                    }
                });
                
                threads.execute(thread);
                
            }   
            
        }catch(Exception e){
            System.err.println("Error when generating a classifier.");
            e.printStackTrace();
            System.exit(0);
        }
        
        
        
    }
    
    //Function to recover experiments
    public static void CheckExperiment(File file, ArrayList<Double> accuracies, ArrayList<Double> microPrecisions, ArrayList<Double> microRecalls, ArrayList<Double> macroPrecisions, ArrayList<Double> macroRecalls, ArrayList<Long> buildingTimes, ArrayList<Long> classificationTimes, ArrayList<Integer> iterations){
        try{
            BufferedReader arqResult = new BufferedReader(new FileReader(file));
            String line = "";
            int indRepetition = -1;
            double accuracy = -1;
            double microPrecision = -1;
            double microRecall = -1;
            double macroPrecision = -1;
            double macroRecall = -1;
            long buildingTime = -1;
            long classificationTime = -1;
            int numIterations = -1;
            
            while((line = arqResult.readLine()) != null){
                if(line.contains("Average") || line.contains("Media")){
                    accuracies.add(accuracy);
                    microPrecisions.add(microPrecision);
                    microRecalls.add(microRecall);
                    macroPrecisions.add(macroPrecision);
                    macroRecalls.add(macroRecall);
                    buildingTimes.add(buildingTime);
                    classificationTimes.add(classificationTime);
                    iterations.add(numIterations);
                    return;
                }
                if (line.contains("Repetition") || line.contains("Repetition")){
                    String[] parts = line.split(" ");
                    indRepetition = Integer.parseInt(parts[1]);
                    if((accuracy >= 0) && (microPrecision >= 0) && (microRecall >= 0) && (macroPrecision >= 0) && (macroRecall >= 0)){
                        accuracies.add(accuracy);
                        microPrecisions.add(microPrecision);
                        microRecalls.add(microRecall);
                        macroPrecisions.add(macroPrecision);
                        macroRecalls.add(macroRecall);
                        buildingTimes.add(buildingTime);
                        classificationTimes.add(classificationTime);
                        iterations.add(numIterations);
                    }
                    indRepetition = -1;
                    accuracy = -1;
                    microPrecision = -1;
                    microRecall = -1;
                    macroPrecision = -1;
                    macroRecall = -1;    
                    buildingTime = -1;
                    classificationTime = -1;
                    numIterations = -1;
                }
                if((line.contains("Accuracy") || line.contains("Taxa de Acerto")) && (!line.contains("Average"))){
                    String[] parts = line.split(":");
                    if(parts.length == 2){
                        accuracy = Double.parseDouble(parts[1].trim());
                    }else{
                        accuracy = -1;
                    }
                }
                if((line.contains("Micro-Precision") || line.contains("Micro Precisao")) && (!line.contains("Average"))){
                    String[] parts = line.split(":");
                    if(parts.length == 2){
                        microPrecision = Double.parseDouble(parts[1].trim());
                    }else{
                        microPrecision = -1;
                    }
                }
                if((line.contains("Micro-Recall") || line.contains("Micro Revocacao")) && (!line.contains("Average"))){
                    String[] parts = line.split(":");
                    if(parts.length == 2){
                        microRecall = Double.parseDouble(parts[1].trim());
                    }else{
                        microRecall = -1;
                    }
                }
                if((line.contains("Macro-Precision") || line.contains("Macro Precisao")) && (!line.contains("Average"))){
                    String[] parts = line.split(":");
                    if(parts.length == 2){
                        macroPrecision = Double.parseDouble(parts[1].trim());
                    }else{
                        macroPrecision = -1;
                    }
                }
                if((line.contains("Macro-Recall") || line.contains("Macro Revocacao"))&& (!line.contains("Average"))){
                    String[] parts = line.split(":");
                    if(parts.length == 2){
                        macroRecall = Double.parseDouble(parts[1].trim());
                    }else{
                        macroRecall = -1;
                    }
                }
                if((line.contains("Model Building Time") || line.contains("Tempo Constru")) && (!line.contains("Average"))){
                    String[] parts = line.split(":");
                    if(parts.length == 2){
                        Double value = Double.parseDouble(parts[1].trim()) * 1000;
                        buildingTime = value.longValue();
                    }else{
                        buildingTime = -1;
                    }
                }
                if((line.contains("Classification Time") || line.contains("Tempo Classifi")) && (!line.contains("Average"))){
                    String[] parts = line.split(":");
                    if(parts.length == 2){
                        Double value = Double.parseDouble(parts[1].trim()) * 1000;
                        classificationTime = value.longValue();
                    }else{
                        classificationTime = -1;
                    }
                }
                if((line.contains("Number of Iterations") || line.contains("Itera")) && (!line.contains("Average"))){
                    String[] parts = line.split(":");
                    if(parts.length == 2){
                        numIterations = Integer.parseInt(parts[1].trim());
                    }else{
                        numIterations = -1;
                    }
                }
            }
        }catch(Exception e){
            System.err.println("Error when reading result files.");
            e.printStackTrace();
            System.exit(0);
        }
    }
    
    //Save the classification performance results from a repetition        
    public static void SaveRepetition(File file, double accuracy, double microPrecision, double microRecall, double macroPrecision, double macroRecall, long buildingTime, long classificationTime, int numIterations, int numRepetition){
        try{
            FileWriter outputResults = new FileWriter(file,true);
            outputResults.write("Accuracy (%): " + accuracy + "\n");
            outputResults.write("Error (%): " + (100 - accuracy) + "\n");
            outputResults.write("Micro-Precision: " + microPrecision + "\n");
            outputResults.write("Micro-Recall: " + microRecall + "\n");
            outputResults.write("Macro-Precision: " + macroPrecision + "\n");
            outputResults.write("Macro-Recall: " + macroRecall + "\n");
            outputResults.write("Model Building Time (s): " + ((double)buildingTime / (double)1000) + "\n");
            outputResults.write("Classification Time (s): " + ((double)classificationTime / (double)1000) + "\n");
            outputResults.write("Number of Iterations: " + numIterations + "\n");
            outputResults.close();
        }catch(Exception e){
            System.err.println("Error when saving the results.");
            e.printStackTrace();
            System.exit(0);
        }
        
    }
    
    //Function to save the average of classification performance measures obtained from different repetitions
    public static void SaveAverage(TransductiveConfiguration_DocTermAndTermTermRelations configuration, File file, ArrayList<Double> accuracies, ArrayList<Double> microPrecisions, ArrayList<Double> microRecalls, ArrayList<Double> macroPrecisions, ArrayList<Double> macroRecalls, ArrayList<Long> buildingTimes, ArrayList<Long> classificationTimes, ArrayList<Integer> iterations){
        System.out.println("Saving Results...");
        
        try{
            double acmAccuracy = 0;
            double acmMicroPrecision = 0;
            double acmMicroRecall = 0;
            double acmMacroPrecision = 0;
            double acmMacroRecall = 0;
            long acmBuildingTime = 0;
            long acmClassificationTime = 0;
            int acmiterations = 0;
            
            FileWriter outputResults = new FileWriter(file,true);
            for(int rep=0;rep<configuration.getNumReps();rep++){
                acmAccuracy += accuracies.get(rep);
                acmMicroPrecision += microPrecisions.get(rep);
                acmMicroRecall += microRecalls.get(rep);
                acmMacroPrecision += macroPrecisions.get(rep);
                acmMacroRecall += macroRecalls.get(rep);
                acmBuildingTime += buildingTimes.get(rep);
                acmClassificationTime += classificationTimes.get(rep);
                if(iterations.size() > 0){
                    acmiterations += iterations.get(rep);
                }
            }

            outputResults.write("\n-------------------------------------\n");
                        
            double averageAccuracy = ((double)acmAccuracy / (double)configuration.getNumReps());
            double averageMicroPrecision = ((double)acmMicroPrecision / (double)configuration.getNumReps());
            double averageMicroRecall = ((double)acmMicroRecall / (double)configuration.getNumReps());
            double averageMacroPrecision = ((double)acmMacroPrecision / (double)configuration.getNumReps());
            double averageMacroRecall = ((double)acmMacroRecall / (double)configuration.getNumReps());
            
            //Standard Deviation of the Accuracy
            double acmSD = 0;
            for(int rep=0;rep<configuration.getNumReps();rep++){
                acmSD += Math.pow((accuracies.get(rep) - averageAccuracy), 2);
            }
            acmSD = (double)acmSD / (double)(configuration.getNumReps());
            double desvio = Math.sqrt(acmSD);
            
            outputResults.write("Average Accuracy (%): " + averageAccuracy + "\n");
            outputResults.write("Average Micro-Precision: " + averageMicroPrecision + "\n");
            outputResults.write("Average Micro-Recall: " + averageMicroRecall + "\n");
            outputResults.write("Average Macro-Precision: " + averageMacroPrecision + "\n");
            outputResults.write("Average Macro-Recall: " + averageMacroRecall + "\n");
            outputResults.write("Standard Deviation Accuracy: " + desvio +"\n");
            outputResults.write("Average Model Building Time (s): " + (((double)acmBuildingTime / (double)1000) / (double)configuration.getNumReps())+"\n");
            outputResults.write("Average Classification Time (s): " + (((double)acmClassificationTime / (double)1000) / (double)configuration.getNumReps())+"\n");
            outputResults.write("Average Number of Iterations (s): " + ((double)acmiterations / (double)configuration.getNumReps()) + "\n");

            outputResults.close();
        }catch(Exception e){
            System.err.println("Error when saving the results");
            e.printStackTrace();
            System.exit(0);
        }
    }
    
    /*Function to compute Accuracy, Micro-Precision, Micro-Recall, Macro-Precision, and Macro-Recal */
    private static void ComputeEvaluationMeasures(Integer[][] confusionMatrix, int numClasses, ArrayList<Double> accuracies, ArrayList<Double> microPrecisions, ArrayList<Double> microRecalls, ArrayList<Double> macroPrecisions, ArrayList<Double> macroRecalls){
        
        int tp=0;
        int total=0;
        for(int i=0;i<numClasses;i++){
            for(int j=0;j<numClasses;j++){
                if(i==j){
                    tp += confusionMatrix[i][j];
                }
                total += confusionMatrix[i][j];
            }
        }
        double accuracy = ((double)tp/(double)total) * 100;
        accuracies.add(accuracy);
        
        
        double microPrecTotNum = 0, microPrecTotDen = 0, microRevTotNum = 0, microRevTotDen = 0, macroPrecTot = 0, macroRevTot = 0;
        for(int j=0;j<numClasses;j++){
            
            int TPi = confusionMatrix[j][j];
            int FPi = 0;
            for(int k=0;k<numClasses;k++){
                if(k!=j){
                    FPi += confusionMatrix[j][k];
                }
            }
            microPrecTotNum += TPi;
            microPrecTotDen += (TPi + FPi);
            if((TPi + FPi)==0){
                macroPrecTot += 0;
            }else{
                macroPrecTot += (double)TPi/(double)(TPi + FPi);
            }

            
            int FNi=0;
            for(int k=0;k<numClasses;k++){
                if(k!=j){
                    FNi += confusionMatrix[k][j];
                }
            }
            microRevTotNum += TPi;
            microRevTotDen += TPi + FNi;
            if((TPi + FNi)==0){
                macroRevTot += 0;
            }else{
                macroRevTot += (double)TPi/(double)(TPi + FNi);
            }
        }
        double microPrecision = (double)microPrecTotNum/(double)microPrecTotDen;
        double microRecall = (double)microRevTotNum/(double)microRevTotDen;
        double macroPrecision = (double) macroPrecTot / (double) numClasses;
        double macroRecall = (double)macroRevTot/(double)numClasses;
        microPrecisions.add(microPrecision);
        microRecalls.add(microRecall);
        macroPrecisions.add(macroPrecision);
        macroRecalls.add(macroRecall);
    }
}
