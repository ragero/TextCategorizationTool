//*********************************************************************************
// Author: Rafael Geraldeli Rossi
// E-mail: rgr.rossi at gmail com
// Last-Modified: January 29, 2015
// Description: Class to perform Transductive Learning and Evaluations. The 
//              algorithms are based on document-document relations. The difference
//              between this class and TCT.TransductiveClassification is the
//              document-term matrix and the proximity file. The document-term
//              matrix used in this class must have and ID as first feature and 
//              a proximity file generated considering this matrix
//              (TCTInterface.Interface_Utilities_DocDocProximities.java). 
//              With this there is no need to compute similarities among documents
//              and generate document-document relation for different repetitions.
//**********************************************************************************

package TCT;

import TCTAlgorithms.Transductive.GFHF_DocDoc_ID;
import TCTAlgorithms.Transductive.GFHF_DocDoc_ID_AdjList_Transductive;
import TCTAlgorithms.Transductive.GFHF_DocDoc_ID_DiagMatrix_Transductive;
import TCTAlgorithms.Transductive.TransductiveClassifier;
import TCTAlgorithms.Transductive.LLGC_DocDoc_ID;
import TCTAlgorithms.Transductive.LLGC_DocDoc_ID_AdjList_Transductive;
import TCTAlgorithms.Transductive.LLGC_DocDoc_ID_DiagMatrix_Transductive;
import TCTAlgorithms.Transductive.TCHN_DocDoc_ID_Transductive;
import TCTConfigurations.TransductiveLearning.TransductiveConfiguration_DocDocRelations_ID;
import static TCTNetworkGeneration.DocumentNetworkGeneration_ID.GenerateExpNetworkAdjacencyList;
import static TCTNetworkGeneration.DocumentNetworkGeneration_ID.GenerateGaussianNetworkMatrix;
import static TCTNetworkGeneration.DocumentNetworkGeneration_ID.GenerateKnnNetworkCosineAdjList;
import static TCTNetworkGeneration.DocumentNetworkGeneration_ID.GenerateKnnNetworkCosineMatrix;
import static TCTNetworkGeneration.DocumentNetworkGeneration_ID.GenerateKnnNetworkEuclideanList;
import static TCTNetworkGeneration.DocumentNetworkGeneration_ID.GenerateKnnNetworkEuclideanMatrix;
import TCTParameters.SemiSupervisedLearning.Parameters_GFHF;
import TCTParameters.SemiSupervisedLearning.Parameters_IMHN;
import TCTParameters.SemiSupervisedLearning.Parameters_LLGC;
import TCTStructures.Neighbor;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import weka.core.Attribute;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils;

public class TransductiveClassification_DocDoc_ID {
    
    /*Function to read the data (document-term matrix and document proximities) and build relations among documents. */
    public static void learning(TransductiveConfiguration_DocDocRelations_ID configuration){
    
        File arqMatrizDados = new File(configuration.getMatrizDados());
        if(!arqMatrizDados.exists()){
            System.out.println("Invalid ARFF file.");
            return;
        }
        System.out.println("ARFF file: " + arqMatrizDados.getAbsolutePath());
        File proximityFile = new File(configuration.getMatrizProx());
        if(!proximityFile.exists()){
            System.out.println("Invalid proximity file.");
            return;
        }
        System.out.println("ProximityFile: " + proximityFile.getAbsolutePath());
        File dirResultados = new File(configuration.getDirResultados());
        if(!dirResultados.exists()){
            System.out.println("Invalid result directory.");
            return;
        }
        System.out.println(arqMatrizDados.getAbsolutePath());
        System.out.println("Loading ARFF file");
        try{
            ConverterUtils.DataSource trainSource = new ConverterUtils.DataSource(arqMatrizDados.getAbsolutePath()); //Carregando arquivo de Dados
            Instances dataOriginal = trainSource.getDataSet();
            
            int numInsts = dataOriginal.numInstances();
            int numTerms = dataOriginal.numAttributes();
            int numClasses = 0;
            Attribute classAtt = null;

            classAtt = dataOriginal.attribute(dataOriginal.numAttributes()-1); //Setting the last feature as class
            dataOriginal.setClass(classAtt);
            numClasses = classAtt.numValues();

            for(int j=0;j<numClasses;j++){
                System.out.println(j + ": " + classAtt.value(j));
            }

            StringBuilder outputFile = new StringBuilder();
            StringBuilder outputFilePar = new StringBuilder();
            outputFile.append(configuration.getDirResultados());
            outputFile.append("/");
            outputFile.append(dataOriginal.relationName());
            outputFile.append("_Transductive_DD_");
            
            if(configuration.isLLGC()){
                outputFilePar = new StringBuilder();
                outputFilePar.append(outputFile.toString());
                outputFilePar.append("LLGC_");
                Parameters_LLGC parametersLLGC = configuration.getParametersLLGC();
                if(configuration.isNetworkExp() == true){
                    for(int alpha=0;alpha<parametersLLGC.getAlphas().size();alpha++){
                        for(int sigma=0;sigma<configuration.getParametersExpNetwork().getSigmas().size();sigma++){
                            double valueSigma = configuration.getParametersExpNetwork().getSigma(sigma);
                            double[][] matSim = null;
                            Neighbor[] adjListDocs = null;
                            if(configuration.getAdjList() == true){
                                adjListDocs = GenerateExpNetworkAdjacencyList(proximityFile, valueSigma, numInsts, configuration.getParametersExpNetwork().isCosseno());
                            }else{
                                matSim = GenerateGaussianNetworkMatrix(proximityFile, valueSigma, numInsts, configuration.getParametersExpNetwork().isCosseno());
                            }
                            //System.out.println("Classification Algorithm: LLGC");
                            //System.out.println("Exp Network");
                            //System.out.println("Alpha: " + parametersLLGC.getAlpha(alpha));
                            //System.out.println("Sigma: " + configuration.getParametersExpNetwork().getSigma(sigma));
                            ExecutorService threads = Executors.newFixedThreadPool(configuration.getNumThreads());
                            for(int numEx=0;numEx<configuration.getParametersNumLabeledInstancesPerClass().getNumLabeledInstancesPerClass().size();numEx++){
                                double numLabeledInstances = configuration.getParametersNumLabeledInstancesPerClass().getNumLabeledInstancesPerClass(numEx);
                                //System.out.println("Number of labeled intances per class: " + numLabeledInstances);
                                StringBuilder outputFilePar2 = new StringBuilder();
                                outputFilePar2.append(outputFilePar.toString());
                                outputFilePar2.append(numLabeledInstances);
                                outputFilePar2.append("_");
                                if(configuration.isPorcentage() == true){
                                    outputFilePar2.append("percentage");
                                    outputFilePar2.append("_");
                                }else{
                                    outputFilePar2.append("real");
                                    outputFilePar2.append("_");
                                }
                                outputFilePar2.append("_");
                                outputFilePar2.append("Exp");
                                outputFilePar2.append("_");
                                outputFilePar2.append(configuration.getParametersExpNetwork().getSigma(sigma));
                                outputFilePar2.append("_");
                                outputFilePar2.append(parametersLLGC.getAlpha(alpha));
                                TransductiveClassifier[] classifiers = new TransductiveClassifier[configuration.getNumReps()];
                                for(int rep=0;rep<configuration.getNumReps();rep++){
                                    LLGC_DocDoc_ID classifLLGC = null;
                                    if(configuration.getAdjList()){
                                        classifLLGC = new LLGC_DocDoc_ID_AdjList_Transductive();
                                        classifLLGC.setAdjListDocs(adjListDocs);
                                    }else{
                                        classifLLGC = new LLGC_DocDoc_ID_DiagMatrix_Transductive();
                                        classifLLGC.setMatSim(matSim);
                                    }
                                    classifLLGC.setUse(0);
                                    classifLLGC.setMaxNumIterations(parametersLLGC.getMaxNumberIterations());
                                    classifLLGC.setAlpha(parametersLLGC.getAlpha(alpha));
                                    classifiers[rep] = classifLLGC;
                                }
                                learning(configuration, threads, classifiers, dataOriginal, outputFilePar2.toString(), numLabeledInstances, numClasses);    
                            }
                            threads.shutdown();
                            boolean exit = false;
                            while(exit == false){
                                if(threads.isTerminated()){
                                    exit = true;
                                }else{
                                    Thread.sleep(1000);
                                }
                            }
                        }
                    }    
                
                }
                if(configuration.isNetworkKnn() == true){
                    for(int alpha=0;alpha<parametersLLGC.getAlphas().size();alpha++){
                        for(int k=0;k<configuration.getParametersKnnNetwork().getKs().size();k++){
                            int valueK = configuration.getParametersKnnNetwork().getK(k);
                            double[][] matSim = null;
                            Neighbor[] adjListDocs = null;
                            if(configuration.getAdjList() == true){
                                if(configuration.getParametersKnnNetwork().isCosseno()){
                                    adjListDocs = GenerateKnnNetworkCosineAdjList(proximityFile, valueK, numInsts);
                                }else{
                                    adjListDocs = GenerateKnnNetworkEuclideanList(proximityFile, valueK, numInsts);
                                }
                            }else{
                                if(configuration.getParametersExpNetwork().isCosseno()){
                                    matSim = GenerateKnnNetworkCosineMatrix(proximityFile, valueK, numInsts);
                                }else{
                                    matSim = GenerateKnnNetworkEuclideanMatrix(proximityFile, valueK, numInsts);
                                }
                            }
                            //System.out.println("Classification Algorithm: LLGC");
                            //System.out.println("Doc-Doc Relations: Mutual Knn");
                            //System.out.println("Alpha: " + parametersLLGC.getAlpha(alpha));
                            //System.out.println("K: " + configuration.getParametersKnnNetwork().getK(k));
                            ExecutorService threads = Executors.newFixedThreadPool(configuration.getNumThreads());
                            for(int numEx=0;numEx<configuration.getParametersNumLabeledInstancesPerClass().getNumLabeledInstancesPerClass().size();numEx++){
                                double numLabeledInstances = configuration.getParametersNumLabeledInstancesPerClass().getNumLabeledInstancesPerClass(numEx);
                                //System.out.println("Number of labeled intances per class: " + numLabeledInstances);
                                StringBuilder outputFilePar2 = new StringBuilder();
                                outputFilePar2.append(outputFilePar.toString());
                                outputFilePar2.append(numLabeledInstances);
                                outputFilePar2.append("_");
                                if(configuration.isPorcentage() == true){
                                    outputFilePar2.append("percentage");
                                    outputFilePar2.append("_");
                                }else{
                                    outputFilePar2.append("real");
                                    outputFilePar2.append("_");
                                }
                                outputFilePar2.append("_");
                                outputFilePar2.append("MutualKnn");
                                outputFilePar2.append("_");
                                outputFilePar2.append(configuration.getParametersKnnNetwork().getK(k));
                                outputFilePar2.append("_");
                                outputFilePar2.append(parametersLLGC.getAlpha(alpha));
                                TransductiveClassifier[] classifiers = new TransductiveClassifier[configuration.getNumReps()];
                                for(int rep=0;rep<configuration.getNumReps();rep++){
                                    LLGC_DocDoc_ID classifLLGC = null;
                                    if(configuration.getAdjList()){
                                        classifLLGC = new LLGC_DocDoc_ID_AdjList_Transductive();
                                        classifLLGC.setAdjListDocs(adjListDocs);
                                    }else{
                                        classifLLGC = new LLGC_DocDoc_ID_DiagMatrix_Transductive();
                                        classifLLGC.setMatSim(matSim);
                                    }
                                    classifLLGC.setUse(0);
                                    classifLLGC.setMaxNumIterations(parametersLLGC.getMaxNumberIterations());
                                    classifLLGC.setAlpha(parametersLLGC.getAlpha(alpha));
                                    classifiers[rep] = classifLLGC;
                                }
                                learning(configuration, threads, classifiers, dataOriginal, outputFilePar2.toString(), numLabeledInstances, numClasses);    
                            }
                            threads.shutdown();
                            boolean exit = false;
                            while(exit == false){
                                if(threads.isTerminated()){
                                    exit = true;
                                }else{
                                    Thread.sleep(1000);
                                }
                            }
                        }
                    }    
                }
            }

            if(configuration.isGFHF()){
                outputFilePar = new StringBuilder();
                outputFilePar.append(outputFile.toString());
                outputFilePar.append("GFHF_");
                if(configuration.isPorcentage() == true){
                    outputFilePar.append("percentage");
                    outputFilePar.append("_");
                }else{
                    outputFilePar.append("real");
                    outputFilePar.append("_");
                }
                Parameters_GFHF parametersGFHF = configuration.getParametersGFHF();
                if(configuration.isNetworkExp() == true){
                    for(int sigma=0;sigma<configuration.getParametersExpNetwork().getSigmas().size();sigma++){
                        double valueSigma = configuration.getParametersExpNetwork().getSigma(sigma);
                        double[][] matSim = null;
                        Neighbor[] adjListDocs = null;
                        if(configuration.getAdjList() == true){
                           adjListDocs = GenerateExpNetworkAdjacencyList(proximityFile, valueSigma, numInsts, configuration.getParametersExpNetwork().isCosseno());
                        }else{
                            matSim = GenerateGaussianNetworkMatrix(proximityFile, valueSigma, numInsts, configuration.getParametersExpNetwork().isCosseno());
                        }
                        ExecutorService threads = Executors.newFixedThreadPool(configuration.getNumThreads());
                        for(int numEx=0;numEx<configuration.getParametersNumLabeledInstancesPerClass().getNumLabeledInstancesPerClass().size();numEx++){
                            double numLabeledInstances = configuration.getParametersNumLabeledInstancesPerClass().getNumLabeledInstancesPerClass(numEx);
                            //System.out.println("Number of labeled intances per class: " + numLabeledInstances);
                            //System.out.println("Classification Algorithm: GFHF");
                            //System.out.println("Exp Network");
                            //System.out.println("Sigma: " + configuration.getParametersExpNetwork().getSigma(sigma));
                            StringBuilder outputFilePar2 = new StringBuilder();
                            outputFilePar2.append(outputFilePar.toString());
                            outputFilePar2.append(numLabeledInstances);
                            outputFilePar2.append("_");
                            if(configuration.isPorcentage() == true){
                                outputFilePar2.append("percentage");
                                outputFilePar2.append("_");
                            }else{
                                outputFilePar2.append("real");
                                outputFilePar2.append("_");
                            }
                            outputFilePar2.append("_");
                            outputFilePar2.append("Exp");
                            outputFilePar2.append("_");
                            outputFilePar2.append(configuration.getParametersExpNetwork().getSigma(sigma));
                            TransductiveClassifier[] classifiers = new TransductiveClassifier[configuration.getNumReps()];
                            for(int rep=0;rep<configuration.getNumReps();rep++){
                                GFHF_DocDoc_ID classifGFHF = null;
                                if(configuration.getAdjList() == true){
                                    classifGFHF = new GFHF_DocDoc_ID_AdjList_Transductive();
                                }else{
                                    classifGFHF = new GFHF_DocDoc_ID_DiagMatrix_Transductive();
                                }
                                classifGFHF.setUse(0);
                                if(configuration.getAdjList() == true){
                                    classifGFHF.setAdjListDocs(adjListDocs);
                                }else{
                                    classifGFHF.setMatSim(matSim);
                                }
                                classifGFHF.setMaxNumIterations(parametersGFHF.getMaxNumberIterations());
                                classifiers[rep] = classifGFHF;
                            }
                            learning(configuration, threads, classifiers, dataOriginal, outputFilePar2.toString(), numLabeledInstances, numClasses);    
                        }
                        threads.shutdown();
                        boolean exit = false;
                        while(exit == false){
                            if(threads.isTerminated()){
                                exit = true;
                            }else{
                                Thread.sleep(1000);
                            }
                        }
                    }
                }
                if(configuration.isNetworkKnn() == true){
                    for(int k=0;k<configuration.getParametersKnnNetwork().getKs().size();k++){
                        int valueK = configuration.getParametersKnnNetwork().getK(k);
                        double[][] matSim = null;
                        Neighbor[] adjListDocs = null;
                        if(configuration.getAdjList() == true){
                            if(configuration.getParametersKnnNetwork().isCosseno()){
                                adjListDocs = GenerateKnnNetworkCosineAdjList(proximityFile, valueK, numInsts);
                            }else{
                                adjListDocs = GenerateKnnNetworkEuclideanList(proximityFile, valueK, numInsts);
                            }
                        }else{
                            if(configuration.getParametersExpNetwork().isCosseno()){
                                matSim = GenerateKnnNetworkCosineMatrix(proximityFile, valueK, numInsts);
                            }else{
                                matSim = GenerateKnnNetworkEuclideanMatrix(proximityFile, valueK, numInsts);
                            }
                        }
                        ExecutorService threads = Executors.newFixedThreadPool(configuration.getNumThreads());
                        for(int numEx=0;numEx<configuration.getParametersNumLabeledInstancesPerClass().getNumLabeledInstancesPerClass().size();numEx++){
                            double numLabeledInstances = configuration.getParametersNumLabeledInstancesPerClass().getNumLabeledInstancesPerClass(numEx);
                            //System.out.println("Number of labeled intances per class: " + numLabeledInstances);
                            //System.out.println("Classification Algorithm: GFHF");
                            //System.out.println("Doc-Doc Relations: Mutual Knn");
                            //System.out.println("K: " + configuration.getParametersKnnNetwork().getK(k));
                            StringBuilder outputFilePar2 = new StringBuilder();
                            outputFilePar2.append(outputFilePar.toString());
                            outputFilePar2.append(numLabeledInstances);
                            outputFilePar2.append("_");
                            if(configuration.isPorcentage() == true){
                                outputFilePar2.append("percentage");
                                outputFilePar2.append("_");
                            }else{
                                outputFilePar2.append("real");
                                outputFilePar2.append("_");
                            }
                            outputFilePar2.append("_");
                            outputFilePar2.append("MutualKnn");
                            outputFilePar2.append("_");
                            outputFilePar2.append(configuration.getParametersKnnNetwork().getK(k));
                            TransductiveClassifier[] classifiers = new TransductiveClassifier[configuration.getNumReps()];
                            for(int rep=0;rep<configuration.getNumReps();rep++){
                                GFHF_DocDoc_ID classifGFHF = null;
                                if(configuration.getAdjList() == true){
                                    classifGFHF = new GFHF_DocDoc_ID_AdjList_Transductive();
                                }else{
                                    classifGFHF = new GFHF_DocDoc_ID_DiagMatrix_Transductive();
                                }
                                classifGFHF.setUse(0);
                                if(configuration.getAdjList() == true){
                                    classifGFHF.setAdjListDocs(adjListDocs);
                                }else{
                                    classifGFHF.setMatSim(matSim);
                                }
                                classifGFHF.setMaxNumIterations(parametersGFHF.getMaxNumberIterations());
                                classifiers[rep] = classifGFHF;
                            }
                            learning(configuration, threads, classifiers, dataOriginal, outputFilePar2.toString(), numLabeledInstances, numClasses);    
                        }   
                        threads.shutdown();
                        boolean exit = false;
                        while(exit == false){
                            if(threads.isTerminated()){
                                exit = true;
                            }else{
                                Thread.sleep(1000);
                            }
                        }
                    }
                }
            }
            
            if(configuration.isTCHN()){
                outputFilePar = new StringBuilder();
                outputFilePar.append(outputFile.toString());
                outputFilePar.append("TCHN_DD_ID");
                if(configuration.isPorcentage() == true){
                    outputFilePar.append("percentage");
                    outputFilePar.append("_");
                }else{
                    outputFilePar.append("real");
                    outputFilePar.append("_");
                }
                Parameters_IMHN parametersTCHN = configuration.getParametersTCHN();
                if(configuration.isNetworkExp() == true){
                    for(int sigma=0;sigma<configuration.getParametersExpNetwork().getSigmas().size();sigma++){
                        double valueSigma = configuration.getParametersExpNetwork().getSigma(sigma);
                        double[][] matSim = GenerateGaussianNetworkMatrix(proximityFile, valueSigma, numInsts, configuration.getParametersExpNetwork().isCosseno());
                        ExecutorService threads = Executors.newFixedThreadPool(configuration.getNumThreads());
                        for(int numEx=0;numEx<configuration.getParametersNumLabeledInstancesPerClass().getNumLabeledInstancesPerClass().size();numEx++){
                            double numLabeledInstances = configuration.getParametersNumLabeledInstancesPerClass().getNumLabeledInstancesPerClass(numEx);
                            //System.out.println("Number of labeled intances per class: " + numLabeledInstances);
                            //System.out.println("Classification Algorithm: GFHF");
                            //System.out.println("Exp Network");
                            //System.out.println("Sigma: " + configuration.getParametersExpNetwork().getSigma(sigma));
                            StringBuilder outputFilePar2 = new StringBuilder();
                            outputFilePar2.append(outputFilePar.toString());
                            outputFilePar2.append(numLabeledInstances);
                            outputFilePar2.append("_");
                            if(configuration.isPorcentage() == true){
                                outputFilePar2.append("percentage");
                                outputFilePar2.append("_");
                            }else{
                                outputFilePar2.append("real");
                                outputFilePar2.append("_");
                            }
                            outputFilePar2.append("_");
                            outputFilePar2.append("Exp");
                            outputFilePar2.append("_");
                            outputFilePar2.append(configuration.getParametersExpNetwork().getSigma(sigma));
                            TransductiveClassifier[] classifiers = new TransductiveClassifier[configuration.getNumReps()];
                            for(int rep=0;rep<configuration.getNumReps();rep++){
                                TCHN_DocDoc_ID_Transductive classifTCHN = new TCHN_DocDoc_ID_Transductive();
                                classifTCHN.setUse(0);
                                classifTCHN.setMatSim(matSim);
                                classifTCHN.setMaxNumIterationsLocal(parametersTCHN.getMaxNumberIterationsLocal());
                                classifTCHN.setMaxNumIterationsGlobal(parametersTCHN.getMaxNumberIterationsGlobal());
                                classifTCHN.setErrorCorrectionRate(0.1);
                                classifiers[rep] = classifTCHN;
                            }
                            learning(configuration, threads, classifiers, dataOriginal, outputFilePar2.toString(), numLabeledInstances, numClasses);    
                        }
                        threads.shutdown();
                        boolean exit = false;
                        while(exit == false){
                            if(threads.isTerminated()){
                                exit = true;
                            }else{
                                Thread.sleep(1000);
                            }
                        }
                    }
                }
                if(configuration.isNetworkKnn() == true){
                    for(int k=0;k<configuration.getParametersKnnNetwork().getKs().size();k++){
                        int valueK = configuration.getParametersKnnNetwork().getK(k);
                        double[][] matSim;
                        if(configuration.getParametersKnnNetwork().isCosseno()){
                            matSim = GenerateKnnNetworkCosineMatrix(proximityFile, valueK, numInsts);
                        }else{
                            matSim = GenerateKnnNetworkEuclideanMatrix(proximityFile, valueK, numInsts);
                        }
                        ExecutorService threads = Executors.newFixedThreadPool(configuration.getNumThreads());
                        for(int numEx=0;numEx<configuration.getParametersNumLabeledInstancesPerClass().getNumLabeledInstancesPerClass().size();numEx++){
                            double numLabeledInstances = configuration.getParametersNumLabeledInstancesPerClass().getNumLabeledInstancesPerClass(numEx);
                            //System.out.println("Number of labeled intances per class: " + numLabeledInstances);
                            //System.out.println("Classification Algorithm: GFHF");
                            //System.out.println("Doc-Doc Relations: Mutual Knn");
                            //System.out.println("K: " + configuration.getParametersKnnNetwork().getK(k));
                            StringBuilder outputFilePar2 = new StringBuilder();
                            outputFilePar2.append(outputFilePar.toString());
                            outputFilePar2.append(numLabeledInstances);
                            outputFilePar2.append("_");
                            if(configuration.isPorcentage() == true){
                                outputFilePar2.append("percentage");
                                outputFilePar2.append("_");
                            }else{
                                outputFilePar2.append("real");
                                outputFilePar2.append("_");
                            }
                            outputFilePar2.append("_");
                            outputFilePar2.append("MutualKnn");
                            outputFilePar2.append("_");
                            outputFilePar2.append(configuration.getParametersKnnNetwork().getK(k));
                            TransductiveClassifier[] classifiers = new TransductiveClassifier[configuration.getNumReps()];
                            for(int rep=0;rep<configuration.getNumReps();rep++){
                                TCHN_DocDoc_ID_Transductive classifTCHN = new TCHN_DocDoc_ID_Transductive();
                                classifTCHN.setUse(0);
                                classifTCHN.setMatSim(matSim);
                                classifTCHN.setMaxNumIterationsLocal(parametersTCHN.getMaxNumberIterationsLocal());
                                classifTCHN.setMaxNumIterationsGlobal(parametersTCHN.getMaxNumberIterationsGlobal());
                                classifTCHN.setErrorCorrectionRate(0.1);
                            }
                            learning(configuration, threads, classifiers, dataOriginal, outputFilePar2.toString(), numLabeledInstances, numClasses);    
                        } 
                        threads.shutdown();
                        boolean exit = false;
                        while(exit == false){
                            if(threads.isTerminated()){
                                exit = true;
                            }else{
                                Thread.sleep(1000);
                            }
                        }
                    }
                }
            }
            
            System.out.println("Process concluded successfully");
            configuration.getEmail().getContent().append(configuration.toString());
            configuration.getEmail().send();
            
        }catch(Exception e){
            System.err.println("Error when generating a classifier.");
            e.printStackTrace();
            System.exit(0);
        }
        
    }
    
    //Function to run and evaluate transductive learning
    public static void learning(final TransductiveConfiguration_DocDocRelations_ID configuration, final ExecutorService threads, final TransductiveClassifier[] classifiers, final Instances dataOriginal, final String outputFile, final double numInstPerClass, final int numClasses){
        try{
            
            final Results results;
            
            final File output = new File(outputFile);
            final File outputResult = new File(output.getAbsolutePath() + ".txt");
            if(outputResult.exists()){
                return;
            }
            final File outputTemp = new File(output.getAbsolutePath() + ".tmp");
            
            if(outputTemp.exists()){
                ObjectInputStream objInput = new ObjectInputStream(new FileInputStream(output.getAbsolutePath() + ".tmp"));
                results = (Results)objInput.readObject();
                objInput.close();
            }else{
                results = new Results(output, configuration.getNumReps(), 1, "Transductive");
            }
            
            //System.out.println("Output: " + output.getAbsolutePath());
            
            for(int rep=0;rep<configuration.getNumReps();rep++){
                
                if(results.getComplete(rep, 0) == true){
                    continue;
                }
                
                final int numRep = rep;
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run(){
                        Integer[][] confusionMatrix = new Integer[numClasses][numClasses]; 
                        for(int class1=0;class1<numClasses;class1++){
                            for(int class2=0;class2<numClasses;class2++){
                                confusionMatrix[class1][class2] = 0;
                            }
                        }

                        Instances dataTrain = new Instances(dataOriginal,0);
                        Instances dataTest = new Instances(dataOriginal,0);

                        Instances data = new Instances(dataOriginal);
                        data.randomize(new Random(numRep));

                        SplitData.splitTrainTestTransductive(configuration, data, dataTrain, dataTest, numInstPerClass);

                        classifiers[numRep].setNumIterations(0);
                        long begin = System.currentTimeMillis();
                        try{
                            classifiers[numRep].buildClassifier(dataTrain, dataTest);
                        }catch(OutOfMemoryError e){
                            e.printStackTrace();
                            System.exit(0);
                        }catch(Exception e){
                            e.printStackTrace();
                            System.exit(0);
                        }
                        
                        long end  = System.currentTimeMillis();
                        results.setBuildingTime(numRep, 0, end - begin);
                        results.setNumIterations(numRep, 0, classifiers[numRep].getNumiterations());
                        begin = System.currentTimeMillis();
                        Evaluations.TransductiveEvaluation(classifiers[numRep], dataTest, confusionMatrix);
                        end = System.currentTimeMillis();
                        results.setClassificationTime(numRep, 0, end - begin);

                        results.computeEvaluationMeasures(confusionMatrix, numClasses, numRep, 0);
                        results.setComplete(numRep, 0, true);
                        
                    }
                });
                
                threads.execute(thread);
                
            }   
            
        }catch(Exception e){
            System.err.println("Error when generating a classifier.");
            e.printStackTrace();
            System.exit(0);
        }
        
        
    }
    
    //Function to recover experiments
    public static void CheckExperiment(File file, ArrayList<Double> accuracies, ArrayList<Double> microPrecisions, ArrayList<Double> microRecalls, ArrayList<Double> macroPrecisions, ArrayList<Double> macroRecalls, ArrayList<Long> buildingTimes, ArrayList<Long> classificationTimes, ArrayList<Integer> iterations){
        try{
            BufferedReader arqResult = new BufferedReader(new FileReader(file));
            String line = "";
            int indRepetition = -1;
            double accuracy = -1;
            double microPrecision = -1;
            double microRecall = -1;
            double macroPrecision = -1;
            double macroRecall = -1;
            long buildingTime = -1;
            long classificationTime = -1;
            int numIterations = -1;
            
            while((line = arqResult.readLine()) != null){
                if(line.contains("Average") || line.contains("Media")){
                    accuracies.add(accuracy);
                    microPrecisions.add(microPrecision);
                    microRecalls.add(microRecall);
                    macroPrecisions.add(macroPrecision);
                    macroRecalls.add(macroRecall);
                    buildingTimes.add(buildingTime);
                    classificationTimes.add(classificationTime);
                    iterations.add(numIterations);
                    return;
                }
                if (line.contains("Repetition") || line.contains("Repetition")){
                    String[] parts = line.split(" ");
                    indRepetition = Integer.parseInt(parts[1]);
                    if((accuracy >= 0) && (microPrecision >= 0) && (microRecall >= 0) && (macroPrecision >= 0) && (macroRecall >= 0)){
                        accuracies.add(accuracy);
                        microPrecisions.add(microPrecision);
                        microRecalls.add(microRecall);
                        macroPrecisions.add(macroPrecision);
                        macroRecalls.add(macroRecall);
                        buildingTimes.add(buildingTime);
                        classificationTimes.add(classificationTime);
                        iterations.add(numIterations);
                    }
                    indRepetition = -1;
                    accuracy = -1;
                    microPrecision = -1;
                    microRecall = -1;
                    macroPrecision = -1;
                    macroRecall = -1;    
                    buildingTime = -1;
                    classificationTime = -1;
                    numIterations = -1;
                }
                if((line.contains("Accuracy") || line.contains("Taxa de Acerto")) && (!line.contains("Average"))){
                    String[] parts = line.split(":");
                    if(parts.length == 2){
                        accuracy = Double.parseDouble(parts[1].trim());
                    }else{
                        accuracy = -1;
                    }
                }
                if((line.contains("Micro-Precision") || line.contains("Micro Precisao")) && (!line.contains("Average"))){
                    String[] parts = line.split(":");
                    if(parts.length == 2){
                        microPrecision = Double.parseDouble(parts[1].trim());
                    }else{
                        microPrecision = -1;
                    }
                }
                if((line.contains("Micro-Recall") || line.contains("Micro Revocacao")) && (!line.contains("Average"))){
                    String[] parts = line.split(":");
                    if(parts.length == 2){
                        microRecall = Double.parseDouble(parts[1].trim());
                    }else{
                        microRecall = -1;
                    }
                }
                if((line.contains("Macro-Precision") || line.contains("Macro Precisao")) && (!line.contains("Average"))){
                    String[] parts = line.split(":");
                    if(parts.length == 2){
                        macroPrecision = Double.parseDouble(parts[1].trim());
                    }else{
                        macroPrecision = -1;
                    }
                }
                if((line.contains("Macro-Recall") || line.contains("Macro Revocacao"))&& (!line.contains("Average"))){
                    String[] parts = line.split(":");
                    if(parts.length == 2){
                        macroRecall = Double.parseDouble(parts[1].trim());
                    }else{
                        macroRecall = -1;
                    }
                }
                if((line.contains("Model Building Time") || line.contains("Tempo Constru")) && (!line.contains("Average"))){
                    String[] parts = line.split(":");
                    if(parts.length == 2){
                        Double value = Double.parseDouble(parts[1].trim()) * 1000;
                        buildingTime = value.longValue();
                    }else{
                        buildingTime = -1;
                    }
                }
                if((line.contains("Classification Time") || line.contains("Tempo Classifi")) && (!line.contains("Average"))){
                    String[] parts = line.split(":");
                    if(parts.length == 2){
                        Double value = Double.parseDouble(parts[1].trim()) * 1000;
                        classificationTime = value.longValue();
                    }else{
                        classificationTime = -1;
                    }
                }
                if((line.contains("Number of Iterations") || line.contains("Itera")) && (!line.contains("Average"))){
                    String[] parts = line.split(":");
                    if(parts.length == 2){
                        numIterations = Integer.parseInt(parts[1].trim());
                    }else{
                        numIterations = -1;
                    }
                }
            }
        }catch(Exception e){
            System.err.println("Error when reading result files.");
            e.printStackTrace();
            System.exit(0);
        }
    }
    
    //Save the classification performance results from a repetition        
    public static void SaveRepetition(File file, double accuracy, double microPrecision, double microRecall, double macroPrecision, double macroRecall, long buildingTime, long classificationTime, int numIterations, int numRepetition){
        try{
            FileWriter outputResults = new FileWriter(file,true);
            outputResults.write("Accuracy (%): " + accuracy + "\n");
            outputResults.write("Error (%): " + (100 - accuracy) + "\n");
            outputResults.write("Micro-Precision: " + microPrecision + "\n");
            outputResults.write("Micro-Recall: " + microRecall + "\n");
            outputResults.write("Macro-Precision: " + macroPrecision + "\n");
            outputResults.write("Macro-Recall: " + macroRecall + "\n");
            outputResults.write("Model Building Time (s): " + ((double)buildingTime / (double)1000) + "\n");
            outputResults.write("Classification Time (s): " + ((double)classificationTime / (double)1000) + "\n");
            outputResults.write("Number of Iterations: " + numIterations + "\n");
            outputResults.close();
        }catch(Exception e){
            System.err.println("Error when saving results.");
            e.printStackTrace();
            System.exit(0);
        }
        
    }
    
    //Function to save the average of classification performance measures obtained from different repetitions
    public static void SaveAverage(TransductiveConfiguration_DocDocRelations_ID configuration, File file, ArrayList<Double> accuracies, ArrayList<Double> microPrecisions, ArrayList<Double> microRecalls, ArrayList<Double> macroPrecisions, ArrayList<Double> macroRecalls, ArrayList<Long> buildingTimes, ArrayList<Long> classificationTimes, ArrayList<Integer> iterations){
        System.out.println("Saving Results...");
        
        try{
            double acmAccuracy = 0;
            double acmMicroPrecision = 0;
            double acmMicroRecall = 0;
            double acmMacroPrecision = 0;
            double acmMacroRecall = 0;
            long acmBuildingTime = 0;
            long acmClassificationTime = 0;
            int acmiterations = 0;
            
            FileWriter outputResults = new FileWriter(file,true);
            for(int rep=0;rep<configuration.getNumReps();rep++){
                acmAccuracy += accuracies.get(rep);
                acmMicroPrecision += microPrecisions.get(rep);
                acmMicroRecall += microRecalls.get(rep);
                acmMacroPrecision += macroPrecisions.get(rep);
                acmMacroRecall += macroRecalls.get(rep);
                acmBuildingTime += buildingTimes.get(rep);
                acmClassificationTime += classificationTimes.get(rep);
                if(iterations.size() > 0){
                    acmiterations += iterations.get(rep);
                }
            }

            outputResults.write("\n-------------------------------------\n");
                        
            double averageAccuracy = ((double)acmAccuracy / (double)configuration.getNumReps());
            double averageMicroPrecision = ((double)acmMicroPrecision / (double)configuration.getNumReps());
            double averageMicroRecall = ((double)acmMicroRecall / (double)configuration.getNumReps());
            double averageMacroPrecision = ((double)acmMacroPrecision / (double)configuration.getNumReps());
            double averageMacroRecall = ((double)acmMacroRecall / (double)configuration.getNumReps());
            
            //Standard Deviation of the Accuracy
            double acmSD = 0;
            for(int rep=0;rep<configuration.getNumReps();rep++){
                acmSD += Math.pow((accuracies.get(rep) - averageAccuracy), 2);
            }
            acmSD = (double)acmSD / (double)(configuration.getNumReps());
            double desvio = Math.sqrt(acmSD);
            
            outputResults.write("Average Accuracy (%): " + averageAccuracy + "\n");
            outputResults.write("Average Micro-Precision: " + averageMicroPrecision + "\n");
            outputResults.write("Average Micro-Recall: " + averageMicroRecall + "\n");
            outputResults.write("Average Macro-Precision: " + averageMacroPrecision + "\n");
            outputResults.write("Average Macro-Recall: " + averageMacroRecall + "\n");
            outputResults.write("Standard Deviation Accuracy: " + desvio +"\n");
            outputResults.write("Average Model Building Time (s): " + (((double)acmBuildingTime / (double)1000) / (double)configuration.getNumReps())+"\n");
            outputResults.write("Average Classification Time (s): " + (((double)acmClassificationTime / (double)1000) / (double)configuration.getNumReps())+"\n");
            outputResults.write("Average Number of Iterations (s): " + ((double)acmiterations / (double)configuration.getNumReps()) + "\n");

            outputResults.close();
        }catch(Exception e){
            System.err.println("Error when saving the results.");
            e.printStackTrace();
            System.exit(0);
        }
    }
    
    /*Function to split text collection into train (labeled) and test (unlabeled) sets. Test data are used as unlabeled data in transductive learning and for evaluation. 
      numInstPerClass instances for each class are selected as labeled examples.*/
    private static void SplitTrainTest(TransductiveConfiguration_DocDocRelations_ID configuration, Instances data, Instances dataTrain, Instances dataTest, double numInstPerClass){
        int numClasses = data.numClasses();
        int[] totalInstClass = new int[numClasses];
        int[] instPerClass = new int[numClasses];
        int[] instChosenByClass = new int[numClasses];
        for(int classe=0;classe<numClasses;classe++){
            totalInstClass[classe] = 0;
            instPerClass[classe] = 0;
            instChosenByClass[classe] = 0;
        }
        
        if(configuration.isPorcentage() == true){
            for(int inst=0;inst<data.numInstances();inst++){
                Instance instance = data.instance(inst);
                int classe = (int)instance.classValue();
                int value = totalInstClass[classe];
                value++;
                totalInstClass[classe] = value;
            }    
        }
        
        if(configuration.isPorcentage() == false){
            for(int classe=0;classe<numClasses;classe++){
                instPerClass[classe] = (int)numInstPerClass;
            }    
        }else{
            for(int classe=0;classe<numClasses;classe++){
                double value = totalInstClass[classe] * ((double)numInstPerClass/(double)100);
                if(value < 1){
                    value = 1;
                }
                instPerClass[classe] = (int)value;
            }
        }
        
        for(int inst=0;inst<data.numInstances();inst++){
            Instance instance = data.instance(inst);
            int classe = (int)instance.classValue();
            int value = instChosenByClass[classe];
            value++;
            if(value > instPerClass[classe]){
                dataTest.add(instance);
            }else{
                dataTrain.add(instance);
                instChosenByClass[classe] = value;
            }
        }
    }
    
    /*Function to compute Accuracy, Micro-Precision, Micro-Recall, Macro-Precision, and Macro-Recal */
    private static void ComputeEvaluationMeasures(Integer[][] confusionMatrix, int numClasses, ArrayList<Double> accuracies, ArrayList<Double> microPrecisions, ArrayList<Double> microRecalls, ArrayList<Double> macroPrecisions, ArrayList<Double> macroRecalls){
        
        int tp=0;
        int total=0;
        for(int i=0;i<numClasses;i++){
            for(int j=0;j<numClasses;j++){
                if(i==j){
                    tp += confusionMatrix[i][j];
                }
                total += confusionMatrix[i][j];
            }
        }
        double accuracy = ((double)tp/(double)total) * 100;
        accuracies.add(accuracy);
        
        
        double microPrecTotNum = 0, microPrecTotDen = 0, microRevTotNum = 0, microRevTotDen = 0, macroPrecTot = 0, macroRevTot = 0;
        for(int j=0;j<numClasses;j++){
            
            int TPi = confusionMatrix[j][j];
            int FPi = 0;
            for(int k=0;k<numClasses;k++){
                if(k!=j){
                    FPi += confusionMatrix[j][k];
                }
            }
            microPrecTotNum += TPi;
            microPrecTotDen += (TPi + FPi);
            if((TPi + FPi)==0){
                macroPrecTot += 0;
            }else{
                macroPrecTot += (double)TPi/(double)(TPi + FPi);
            }

            
            int FNi=0;
            for(int k=0;k<numClasses;k++){
                if(k!=j){
                    FNi += confusionMatrix[k][j];
                }
            }
            microRevTotNum += TPi;
            microRevTotDen += TPi + FNi;
            if((TPi + FNi)==0){
                macroRevTot += 0;
            }else{
                macroRevTot += (double)TPi/(double)(TPi + FNi);
            }
        }
        double microPrecision = (double)microPrecTotNum/(double)microPrecTotDen;
        double microRecall = (double)microRevTotNum/(double)microRevTotDen;
        double macroPrecision = (double) macroPrecTot / (double) numClasses;
        double macroRecall = (double)macroRevTot/(double)numClasses;
        microPrecisions.add(microPrecision);
        microRecalls.add(microRecall);
        macroPrecisions.add(macroPrecision);
        macroRecalls.add(macroRecall);
    }
    
}
