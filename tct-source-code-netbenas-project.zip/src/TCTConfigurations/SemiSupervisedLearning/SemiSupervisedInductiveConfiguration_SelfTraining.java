//*****************************************************************************
// Author: Rafael Geraldeli Rossi
// E-mail: rgr.rossi at gmail com
// Last-Modified: January 29, 2015
// Description: 
//*****************************************************************************

package TCTConfigurations.SemiSupervisedLearning;

import TCTParameters.SemiSupervisedLearning.Parameters_KNN;
import TCTParameters.Parameters_NumLabeledDocsAddTraining;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author ragero
 */
public class SemiSupervisedInductiveConfiguration_SelfTraining extends SemiSupervisedInductiveConfigurationBase implements Serializable{
    
    private String dirEntrada;
    private String dirSaida;
    
    private boolean MNB;
    private boolean KNN;
    
    private Parameters_KNN parametersKNN;
    
    private Parameters_NumLabeledDocsAddTraining numInstPerClassInseridosTreinamento = new Parameters_NumLabeledDocsAddTraining();
    
    public SemiSupervisedInductiveConfiguration_SelfTraining(){
        super();
        
        setMNB(false);
        setKNN(false);
        
        parametersKNN = new Parameters_KNN();
        parametersKNN.setNeighbors(new ArrayList<Integer>());
        parametersKNN.addNeighbors(1);
    }

    public String getDirEntrada() {
        return dirEntrada;
    }

    public String getDirSaida() {
        return dirSaida;
    }
    
    public void setDirEntrada(String dirEntrada) {
        this.dirEntrada = dirEntrada;
    }

    public void setDirSaida(String dirSaida) {
        this.dirSaida = dirSaida;
    }  
    
    public boolean isMNB() {
        return MNB;
    }
    
    public boolean isKNN(){
        return KNN;
    }
    
    public void setKNN(boolean KNN){
        this.KNN = KNN;
    }
    
    public void setMNB(boolean MNB) {
        this.MNB = MNB;
    }

    public Parameters_NumLabeledDocsAddTraining getParametersnumInstPerClassInseridosTreinamento(){
        return this.numInstPerClassInseridosTreinamento;
    }
    
    public Parameters_KNN getParametersKNN() {
        return this.parametersKNN;
    }
    
    public void setParametersKNN(Parameters_KNN parametersKNN) {
        this.parametersKNN = parametersKNN;
    }
}
