//*****************************************************************************
// Author: Rafael Geraldeli Rossi
// E-mail: rgr.rossi at gmail com
// Last-Modified: January 29, 2015
// Description: 
//*****************************************************************************  

package TCTParameters;

import java.io.Serializable;
import java.util.ArrayList;

public class Parameters_NumLabeledDocsAddTraining implements Serializable{
    private ArrayList<Double> numInstPerClassInseridosTreinamento;
    
    public Parameters_NumLabeledDocsAddTraining(){
        setnumInstPerClassInseridosTreinamento(new ArrayList<Double>());
        addnumInstPerClassInseridosTreinamento(5.0);
        addnumInstPerClassInseridosTreinamento(10.0);
        addnumInstPerClassInseridosTreinamento(15.0);
        addnumInstPerClassInseridosTreinamento(20.0);
    }
    
    public ArrayList<Double> getnumInstPerClassInseridosTrainamento() {
        return numInstPerClassInseridosTreinamento;
    }
    
    public double getnumInstPerClassInseridosTreinamento(int pos) {
        return numInstPerClassInseridosTreinamento.get(pos);
    }
    
    public void setnumInstPerClassInseridosTreinamento(ArrayList<Double> NumLabeledInstancesPerClass) {
        this.numInstPerClassInseridosTreinamento = NumLabeledInstancesPerClass;
    }
    
    public void addnumInstPerClassInseridosTreinamento(double numEx){
        this.numInstPerClassInseridosTreinamento.add(numEx);
    }
}
