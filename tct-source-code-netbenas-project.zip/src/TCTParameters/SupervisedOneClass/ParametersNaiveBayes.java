/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TCTParameters.SupervisedOneClass;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.NumberFormat;

/**
 *
 * @author deni
 */
public class ParametersNaiveBayes extends ParametersOneClass implements Serializable{
        
    public ParametersNaiveBayes(){
        super(); 
        
        for(int expoente=1;expoente<=50;expoente++){
            String mask = "";
            for(int m=1;m<=expoente;m++){
                mask += "0";
            } 
            DecimalFormat df = new DecimalFormat("0." + mask);
            //NumberFormat df = NumberFormat.getNumberInstance();
            
            for(int base=9;base>=1;base--){
                double value = base * (1 / Math.pow(10, expoente));
                double parametro = Double.parseDouble(df.format(value).replace(',', '.'));
                this.addThreshold(parametro);
            }
            
        }
        
    }
    
}
