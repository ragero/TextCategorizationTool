//*****************************************************************************
// Author: Rafael Geraldeli Rossi
// E-mail: rgr.rossi at gmail com
// Last-Modified: January 29, 2015
// Description: 
//*****************************************************************************  

package TCTParameters.SemiSupervisedLearning;

import java.io.Serializable;
import java.util.ArrayList;

public class Parameters_EM implements Serializable{
    
    private int maxNumberInterations; // Maximum number of iterations
    private double minLogLikelihood;
    private ArrayList<Double> weightsNaoRotulados = new ArrayList<Double>();
    private ArrayList<Integer> numCompClasses = new ArrayList<Integer>();
    
    public Parameters_EM(){
        setMaxNumIterations(1000);
        setMinLogLikelihood(0);
        
        addPesoNaoRotulado(0.1);
        addPesoNaoRotulado(0.3);
        addPesoNaoRotulado(0.5);
        addPesoNaoRotulado(0.7);
        addPesoNaoRotulado(0.9);
        
        addNumCompClasses(1);
        addNumCompClasses(2);
        addNumCompClasses(5);
        addNumCompClasses(10);
    }
    
    public void addNumCompClasses(int numComp){
        numCompClasses.add(numComp);
    }
    
    public Integer getNumCompClasse(int pos){
        return numCompClasses.get(pos);
    }
    
    public ArrayList<Integer> getNumCompClasses(){
        return numCompClasses;
    }
    
    public void addPesoNaoRotulado(double weightUnlabeled){
        weightsNaoRotulados.add(weightUnlabeled);
    }
    
    public Double getWeightUnlabeledInstances(int pos){
        return weightsNaoRotulados.get(pos);
    }
    
    public ArrayList<Double> getPesosNaoRotulados(){
        return weightsNaoRotulados;
    }
    
    public Integer getMaxNumberIterations(){
        return this.maxNumberInterations;
    }
    
    public Double getMinLogLikelihood(){
        return this.minLogLikelihood;
    }
    
    public void setNumCompClasses(ArrayList<Integer> numCompClasses){
        this.numCompClasses = numCompClasses;
    }
    
    public void setPesosNaoRotulados(ArrayList<Double> weightsNaoRotulados){
        this.weightsNaoRotulados = weightsNaoRotulados;
    }
    
    public void setMaxNumIterations(int maxNumberInterations){
        this.maxNumberInterations = maxNumberInterations;
    }
    
    public void setMinLogLikelihood(double minLogLikelihood){
        this.minLogLikelihood = minLogLikelihood;
    }
}
